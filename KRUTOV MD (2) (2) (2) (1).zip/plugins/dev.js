const { krutov, commands } = require('../krutov');

malvin({
    pattern: "owner",
    alias: ["developer", "dev"],
    desc: "Displays the developer info",
    category: "admin",
    react: "👨‍💻",
    filename: __filename
}, async (conn, mek, m, {
    from, reply, pushname
}) => {
    try {
        const name = pushname || "there";

        const text = `
╭───⌈ *KRUTOV-MD * ⌋───╮
│
│ 👋 Hello *${name}*,
│
│ 🤖 I’m *KRUTOV-MD*, a multi-functional
│    WhatsApp Bot built to assist you!
│
│ 👨‍💻 *OWNER DETAILS:*
│ ───────────────
│ 🧠 *Name* :JADEN AFRIX 
│ 🕯️ *Age* : Unlimited
│ ☎️ *Contact* : wa.me/263784812740
│ ▶️ *YouTube* : Jaden.Afrix-z8f
│    https://www.youtube.com/@jaden.afrix-z8f
│
│ ⚡ Powered by *Jaden Afrix*
│
╰────────────────────╯
        `.trim();

        await conn.sendMessage(
            from,
            {
                image: { url: 'https://ibb.co/60h9gzMB' },
                caption: text,
                contextInfo: {
                    mentionedJid: [m.sender],
                    forwardingScore: 999,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: '120363398430045533@newsletter',
                        newsletterName: '🪀『 KRUTOV-MD 』🪀',
                        serverMessageId: 143
                    },
                    externalAdReply: {
                        title: "KRUTOV-MD Bot",
                        body: "Created with love by Jaden",
                        thumbnailUrl: 'https://ibb.co/60h9gzMB',
                        mediaType: 1,
                        renderLargerThumbnail: true,
                        showAdAttribution: true,
                        mediaUrl: "https://www.youtube.com/@jaden.afrix-z8f",
                        sourceUrl: "https://www.youtube.com/@jaden.afrix-z8f"
                    }
                }
            },
            { quoted: mek }
        );
    } catch (e) {
        console.error("Error in .dev command:", e);
        reply(`❌ Error: ${e.message}`);
    }
});