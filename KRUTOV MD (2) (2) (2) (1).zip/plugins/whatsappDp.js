const { krutov } = require('../krutov');
const fetch = require("node-fetch");
const { getBuffer } = require('../lib/functions');

krutov({
  pattern: "wadp",
  desc: "Download WhatsApp profile picture",
  react: "⏳",
  category: "owner",
  filename: __filename,
  async function({ text, send }) {
    if (!text) {
      return send("⚠️ *Error*: Please provide a WhatsApp number in international format (e.g., +1234567890).");
    }
    
    const phoneRegex = /^\+([1-9]{1,4})?([0-9]{7,15})$/;
    if (!phoneRegex.test(text)) {
      return send("⚠️ *Error*: The number format is incorrect. Please use international format, e.g., +1234567890.");
    }
    
    try {
      const imageUrl = await fetchWhatsAppDP(text);
      
      if (imageUrl) {
        const thumbnailBuffer = await getBuffer(imageUrl);
        
        await send({
          image: { url: imageUrl },
          caption: "*Here is the WhatsApp profile picture!*",
          contextInfo: {
            forwardingScore: 999,
            isForwarded: true,
            externalAdReply: {
              title: 'WhatsApp Profile Picture',
              body: `Profile picture of ${text}`,
              mediaType: 1,
              sourceUrl: `https://wa.me/${text.replace(/\+/g, '')}`,
              thumbnail: thumbnailBuffer,
            },
          },
        });
      } else {
        send("❌ *Failed*: Could not fetch the profile picture. The number might be incorrect, or the profile is private.");
      }
    } catch (error) {
      console.error("Error fetching WhatsApp DP:", error);
      send("⚠️ *Error*: Something went wrong while fetching the profile picture. Please try again later.");
    }
  }
});

async function fetchWhatsAppDP(number) {
  try {
    const apiUrl = `https://toolzin.com/tools/whatsapp-dp-downloader/api?number=${encodeURIComponent(number)}`;
    const response = await fetch(apiUrl);
    
    if (!response.ok) {
      throw new Error(`HTTP error! Status: ${response.status}`);
    }
    
    const data = await response.json();
    
    if (data.status === "success" && data.imageUrl) {
      return data.imageUrl;
    }
    
    return null;
  } catch (error) {
    console.error("Error fetching WhatsApp DP:", error);
    return null;
  }
}