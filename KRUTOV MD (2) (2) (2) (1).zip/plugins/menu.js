const config = require('../settings');
const { krutov, commands } = require('../krutov');
const os = require("os");
const { runtime } = require('../lib/functions');

krutov({
    pattern: "menu",
    alias: ["list"],
    desc: "menu the bot",
    react: "📜",
    category: "menu"
}, async (conn, mek, m, {
    from, quoted, body, isCmd, command, args, q,
    isGroup, sender, senderNumber, botNumber2, botNumber,
    pushname, isMe, isOwner, groupMetadata, groupName,
    participants, groupAdmins, isBotAdmins, isAdmins, reply
}) => {
    try {
        const botName = config.BOT_NAME || "KRUTOV-MD";
        const ownerName = config.OWNER_NAME || "Jaden-Afrix";
        const botMode = config.MODE || "public";
        const botPrefix = config.PREFIX || ".";
        const botowner = config.king || "Jaden-Afrix";
        const botVersion = config.version || "4.0";
        const currentTime = new Date().toLocaleString();
        const totalCommands = Object.keys(commands).length;

        let menu = {
            main: '', menu: '', download: '', group: '', owner: '', convert: '', search: '',
            utility: '', fun: '', owner1: '', sticker: '', tools: '', info: '', other: '',
            random: '', misc: '', settings: '', anime: '', support: '', nsfw: '', movie: '',
            admin: '', game: '', stalk: '', logo: '', ai: ''
        };

        for (let key in commands) {
            const cmd = commands[key];
            if (cmd.pattern && !cmd.dontAddCommandList && menu[cmd.category] !== undefined) {
                menu[cmd.category] += `*┊❍* ${cmd.pattern}\n`;
            }
        }

        let desc = `...`; // Keep your original `desc` here, omitted for brevity

        const vv = await conn.sendMessage(from, {
            image: { url: "https://files.catbox.moe/2prjby.jpg" },
            caption: desc,
            contextInfo: {
                mentionedJid: [''],
                forwardingScore: 999,
                isForwarded: true,
                forwardedNewsletterMessageInfo: {
                    newsletterJid: '120363398430045533@newsletter',
                    newsletterName: "Jaden-Afrix",
                    serverMessageId: 999
                },
                externalAdReply: {
                    title: 'Subscribe to YouTube',
                    body: `${pushname}`,
                    mediaType: 1,
                    sourceUrl: "https://www.youtube.com/@jaden.afrix-z8f",
                    thumbnailUrl: "https://www.youtube.com/@jaden.afrix-z8f",
                    previewType: 'PHOTO',
                    renderSmallerThumbnail: true,
                    showAdAttribution: true
                }
            }
        }, { quoted: mek });

        await conn.sendMessage(from, {
            audio: { url: 'https://github.com/XdKing2/MALVIN-DATA/raw/refs/heads/main/autovoice/menu.mp3' },
            mimetype: 'audio/mp4',
            ptt: true
        }, { quoted: mek });

        conn.ev.on('messages.upsert', async (msgUpdate) => {
            const msg = msgUpdate.messages?.[0];
            if (!msg?.message?.extendedTextMessage) return;

            const selectedOption = msg.message.extendedTextMessage.text.trim();
            const repliedToId = msg.message.extendedTextMessage.contextInfo?.stanzaId;

            if (repliedToId === vv.key.id) {
                const categoryMap = {
                    '1': { title: "ᴀᴅᴍɪɴ ᴍᴇɴᴜ", content: menu.admin, thumb: "https://ibb.co/JWcCCbLf" },
                    '2': { title: "ᴘʀɪᴠᴀᴛᴇ ᴍᴇɴᴜ", content: menu.owner, thumb: "https://ibb.co/JWcCCbLf" },
                    '3': { title: "ɢʜᴏsᴛ ᴍᴇɴᴜ", content: menu.owner1, thumb: "https://ibb.co/JWcCCbLf" },
                    '4': { title: "ɪɴғᴏ ᴍᴇɴᴜ", content: menu.info, thumb: "https://ibb.co/JWcCCbLf" },
                    '5': { title: "sᴇᴛᴛɪɴɢs ᴍᴇɴᴜ", content: menu.settings, thumb: "https://ibb.co/JWcCCbLf" },
                    '6': { title: "ᴏᴡɴᴇʀ ᴍᴇɴᴜ", content: menu.owner, thumb: "https://ibb.co/JWcCCbLf" },
                    '7': { title: "ᴅᴏᴡɴʟᴏᴀᴅ ᴍᴇɴᴜ", content: menu.download, thumb: "https://ibb.co/JWcCCbLf" },
                    '8': { title: "ᴍᴏᴠɪᴇ ᴍᴇɴᴜ", content: menu.movie, thumb: "https://ibb.co/JWcCCbLf" },
                    '9': { title: "ᴍᴀɪɴ ᴍᴇɴᴜ", content: menu.main, thumb: "https://ibb.co/JWcCCbLf" },
                    '10': { title: "ɢʀᴏᴜᴘ ᴍᴇɴᴜ", content: menu.group, thumb: "https://ibb.co/JWcCCbLf" },
                    '11': { title: "ᴄᴏɴᴠᴇʀᴛ ᴍᴇɴᴜ", content: menu.convert, thumb: "https://ibb.co/JWcCCbLf" },
                    '12': { title: "sᴇᴀʀᴄʜ ᴍᴇɴᴜ", content: menu.search, thumb: "https://ibb.co/JWcCCbLf" },
                    '13': { title: "ᴜᴛɪʟɪᴛʏ ᴍᴇɴᴜ", content: menu.utility, thumb: "https://ibb.co/JWcCCbLf" },
                    '14': { title: "ғᴜɴ ᴍᴇɴᴜ", content: menu.fun, thumb: "https://ibb.co/JWcCCbLf" },
                    '15': { title: "ᴛᴏᴏʟs ᴍᴇɴᴜ", content: menu.tools, thumb: "https://ibb.co/JWcCCbLf" },
                    '16': { title: "sᴛɪᴄᴋᴇʀ ᴍᴇɴᴜ", content: menu.sticker, thumb: "https://ibb.co/JWcCCbLf" },
                    '17': { title: "ʀᴀɴᴅᴏᴍ ᴍᴇɴᴜ", content: menu.random, thumb: "https://ibb.co/JWcCCbLf" },
                    '18': { title: "ᴍɪsᴄ ᴍᴇɴᴜ", content: menu.misc, thumb: "https://ibb.co/JWcCCbLf" },
                    '19': { title: "ᴀɴɪᴍᴇ ᴍᴇɴᴜ", content: menu.anime, thumb: "https://ibb.co/JWcCCbLf" },
                    '20': { title: "sᴜᴘᴘᴏʀᴛ ᴍᴇɴᴜ", content: menu.support, thumb: "https://ibb.co/JWcCCbLf" },
                    '21': { title: "ᴀɪ ᴍᴇɴᴜ", content: menu.ai, thumb: "https://ibb.co/JWcCCbLf" },
                    '22': { title: "ᴏᴛʜᴇʀ ᴍᴇɴᴜ", content: menu.other, thumb: "https://ibb.co/JWcCCbLf" },
                    '23': { title: "ɴsғᴡ ᴍᴇɴᴜ", content: menu.nsfw, thumb: "https://ibb.co/JWcCCbLf" },
                    '24': { title: "ɢᴀᴍᴇ ᴍᴇɴᴜ", content: menu.game, thumb: "https://ibb.co/JWcCCbLf" },
                    '25': { title: "sᴛᴀʟᴋ ᴍᴇɴᴜ", content: menu.stalk, thumb: "https://ibb.co/JWcCCbLf" },
                    '26': { title: "ʟᴏɢᴏ ᴍᴇɴᴜ", content: menu.logo, thumb: "https://ibb.co/JWcCCbLf" }
                };

                const cat = categoryMap[selectedOption];
                if (!cat) return;

                const replyMsg = `*✦『 ${cat.title} 』✦*\n${cat.content}\n\n${config.DESCRIPTION}`;

                await conn.sendMessage(from, {
                    image: { url: cat.thumb },
                    caption: replyMsg,
                    contextInfo: {
                        mentionedJid: [m.sender],
                        forwardingScore: 999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: '120363398430045533@newsletter',
                            newsletterName: `👤${cat.title}`,
                            serverMessageId: 143
                        }
                    }
                }, { quoted: mek });
            }
        });

    } catch (e) {
        console.error(e);
        reply("An error occurred while displaying the menu.");
    }
});