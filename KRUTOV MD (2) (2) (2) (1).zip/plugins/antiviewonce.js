const { krutov } = require("../krutov");

krutov({
  pattern: "vv",
  alias: ["viewonce", 'retrive'],
  react: '👻',
  desc: "Owner Only - retrieve quoted message back to user",
  category: "owner",
  filename: __filename
}, async (client, message, match, { from, isOwner }) => {
  if (!isOwner) {
    return client.sendMessage(from, {
      text: "*📛 This is an owner command. You're not the owner!*"
    }, { quoted: message });
  }

  if (!match.quoted) {
    return client.sendMessage(from, {
      text: "*🍁 Please reply to a view once message!*"
    }, { quoted: message });
  }

  try {
    const buffer = await match.quoted.download();
    const mtype = match.quoted.mtype;
    const options = { quoted: message };
    
    let messageContent;

    // Create a function to handle message sending
    const sendMessage = async (contentType) => {
      await client.sendMessage(from, contentType, options);
    };

    switch (mtype) {
      case "imageMessage":
        messageContent = {
          image: buffer,
          caption: match.quoted.text || '',
          mimetype: match.quoted.mimetype || "image/jpeg"
        };
        break;
      case "videoMessage":
        messageContent = {
          video: buffer,
          caption: match.quoted.text || '',
          mimetype: match.quoted.mimetype || "video/mp4"
        };
        break;
      case "audioMessage":
        messageContent = {
          audio: buffer,
          mimetype: "audio/mp4",
          ptt: match.quoted.ptt || false
        };
        break;
      case "documentMessage":
        messageContent = {
          document: buffer,
          mimeType: match.quoted.mimetype || "application/octet-stream",
          caption: match.quoted.text || ''
        };
        break;
      default:
        return client.sendMessage(from, {
          text: "❌ Only image, video, audio and document messages are supported"
        }, { quoted: message });
    }

    // Send the message content
    sendMessage(messageContent).catch(async (err) => {
      console.error("Failed to send message:", err);
      await client.sendMessage(from, {
        text: "❌ Error sending retrieved message:\n" + err.message
      }, { quoted: message });
    });

  } catch (error) {
    console.error("vv Error:", error);
    await client.sendMessage(from, {
      text: "❌ Error fetching vv message:\n" + error.message
    }, { quoted: message });
  }
});