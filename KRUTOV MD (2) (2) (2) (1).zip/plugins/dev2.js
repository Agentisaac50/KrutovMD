const { krutov } = require('../krutov');

krutov({
  pattern: "dev2",
  alias: ["developer2", "owner2"],
  desc: "Displays the developer info",
  category: "admin",
  react: "👨‍💻",
  filename: __filename
}, async (conn, mek, m, {
  from,
  reply,
  pushname
}) => {
  try {
    const name = pushname || "there";
    
    const text = `
╭──⌈ *𝗠𝗔𝗟𝗩𝗜𝗡-𝗫�KRUTOV-MD�* ⌋──╮
│
│ 👋 Hello *${name}*,
│
│ 🤖 I’m *KRUTOV-MD�*, a powerful WhatsApp bot
│    created by *Malvin King*!
│
│ 👨‍💻 *OWNER DETAILS:*
│ ───────────────
│ 🧠 *Name* :Jaden Afrix 
│ ☎️ *Contact* : wa.me/263784812740
│ ▶️ *YouTube* : @jaden.afrix-z8f
│    https://youtube.com/@jaden.afrix-z8f
│ 💻 *Source Code* : Coming soon...
│
╰──「 ⚡ Powered by mr krutov 」──╯
        `.trim();
    
    await conn.sendMessage(
      from,
      {
        image: { url: 'https://ibb.co/60h9gzMB' },
        caption: text,
        footer: 'Contact & Support',
        buttons: [
        {
          buttonId: `callowner`,
          buttonText: { displayText: '📞 Call Owner' },
          type: 1
        },
        {
          buttonId: `https://youtube.com/@jaden.afrix-z8f`,
          buttonText: { displayText: '🎬 Join Channel' },
          type: 1
        },
        {
          buttonId: `https://youtube.co/Jaden-Afrix/KRUTOV-MD`, // Replace with your actual source repo if ready
          buttonText: { displayText: '💻 View Source' },
          type: 1
        }],
        headerType: 4,
        contextInfo: {
          mentionedJid: [m.sender],
          forwardingScore: 999,
          isForwarded: true,
          externalAdReply: {
            title: "KRUTOV-MD Bot",
            body: "Created with love by krutov",
            thumbnailUrl: 'https://ibb.co/60h9gzMB',
            mediaType: 1,
            renderLargerThumbnail: true,
            mediaUrl: "https://youtube.com/@jaden.afrix-z8f",
            sourceUrl: "https://youtube.com/@jaden.afrix-z8f"
          }
        }
      }, { quoted: mek }
    );
    
  } catch (e) {
    console.error("Error in .dev command:", e);
    reply(`❌ Error: ${e.message}`);
  }
});