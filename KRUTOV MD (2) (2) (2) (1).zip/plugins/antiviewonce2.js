const { krutov } = require("../krutov");

krutov({
  pattern: "vv2",
  alias: ["wah", "ohh", "oho", "🙂", "nice", "ok"],
  desc: "Owner Only - retrieve quoted view once message back to user",
  category: "owner",
  filename: __filename
}, async (client, message, match, { from, isOwner }) => {
  try {
    // Ensure the user is the owner
    if (!isOwner) {
      return;
    }

    // Check if a message was quoted in the original message
    if (!match.quoted) {
      return await client.sendMessage(from, {
        text: "*🍁 Please reply to a view once message!*"
      }, { quoted: message });
    }

    // Download the quoted message content
    const buffer = await match.quoted.download();
    const mtype = match.quoted.mtype;
    const options = { quoted: message };

    let messageContent = {};
    
    // Determine the type of quoted message and set the corresponding content
    switch (mtype) {
      case 'imageMessage':
        messageContent = {
          image: buffer,
          caption: match.quoted.text || '',
          mimetype: match.quoted.mimetype || 'image/jpeg'
        };
        break;
      case 'videoMessage':
        messageContent = {
          video: buffer,
          caption: match.quoted.text || '',
          mimetype: match.quoted.mimetype || 'video/mp4'
        };
        break;
      case 'audioMessage':
        messageContent = {
          audio: buffer,
          mimetype: 'audio/mp4',
          ptt: match.quoted.ptt || false
        };
        break;
      case 'documentMessage':
        messageContent = {
          document: buffer,
          caption: match.quoted.text || '',
          mimetype: match.quoted.mimetype || 'application/pdf'
        };
        break;      
      default:
        return await client.sendMessage(from, {
          text: "❌ Only image, video, audio and document messages are supported."
        }, { quoted: message });
    }

    // Forward the retrieved content to the owner's direct messages
    await client.sendMessage(message.sender, messageContent, options);
    
  } catch (error) {
    console.error("vv2 Error:", error);
    
    // Send error feedback to the owner if something goes wrong
    await client.sendMessage(from, {
      text: "❌ Error fetching view once message:\n" + error.message
    }, { quoted: message });
  }
});