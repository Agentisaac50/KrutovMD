const { krutov } = require('../krutov');

// Official Links
const CHANNEL_LINK = "https://whatsapp.com/channel/0029VbAhEUWGJP8QRH4IMw0s";
const SUPPORT_LINK = "https://chat.whatsapp.com/H1nv6pTUhFj1tVYoPutW1g";

/**
 * 🟢 Command: Channel
 * 📢 Get the official krutov channel link
 */
krutov({
    pattern: "channel",
    desc: "Get the official Krutov WhatsApp Channel link.",
    react: "🚀",
    category: "support",
    use: ".channel",
    filename: __filename,
}, async (_, mek, __, { reply }) => {
    try {
        reply(
            `🎉 *Welcome to the KRUTOV-MD Official Channel!*\n\n` +
            `🔥 Stay ahead with exclusive updates, new features, and exciting announcements.\n\n` +
            `🔗 *Join Now:* ${CHANNEL_LINK}\n\n` +
            `_Tap the link above and be part of something amazing!_ 🚀\n\n` +
            `💬 If you have any questions or feedback, feel free to reach out! We're here to help!`
        );
    } catch (error) {
        console.error("❌ Error fetching channel link:", error.message);
        reply("⚠️ Oops! I couldn't fetch the channel link. Please try again later or check your connection.");
    }
});

/**
 * 🟢 Command: Support
 * 🛠️ Get help & join the Krutov support group
 */
krutov({
    pattern: "support",
    desc: "Join the KRUTOV-MD Support Group for assistance.",
    react: "💡",
    category: "support",
    use: ".support",
    filename: __filename,
}, async (_, mek, __, { reply }) => {
    try {
        reply(
            `🤝 *Welcome to the KRUTOV-MD Support Hub!*\n\n` +
            `🛠️ Have questions? Facing issues? Or just want to connect with fellow users?\n` +
            `💬 Join our *official support group* where you can ask for help and share feedback.\n\n` +
            `🔗 *Join Here:* ${SUPPORT_LINK}\n\n` +
            `_Your voice matters! Let’s make MALVIN-XD even better together._ 🌟\n\n` +
            `👥 Don't hesitate to share your experiences; we love hearing from our community members!`
        );
    } catch (error) {
        console.error("❌ Error fetching support link:", error.message);
        reply("⚠️ Oops! Something went wrong while fetching the support link. Please check your connection and try again later.");
    }
});

// Additional commands or extensions can be placed here if needed, such as:
// - Command for FAQ
// - Feedback command
// - Any other relevant commands pertaining to user engagement.