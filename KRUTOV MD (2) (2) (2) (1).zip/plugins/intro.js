/*
Project Name : KRUTOV-MD 
Creator      : Jaden ( Jaden Afrix )
Repo         : https://github.com/Jaden-Afrix/KRUTOV-MD
Support      : wa.me/263784812740 or 255 784 534 614
*/

const config = require('../settings');
const { jaden, commands } = require('../jaden');

krutov({
    pattern: "intro",
    alias: ["jaden"],
    react: "🧠",
    desc: "Get owner description",
    category: "info",
    filename: __filename
}, async (conn, mek, m, {
    from, quoted, body, isCmd, command, args, q, isGroup,
    sender, senderNumber, botNumber2, botNumber,
    pushname, isMe, isOwner,
    groupMetadata, groupName,
    participants, groupAdmins,
    isBotAdmins, isAdmins,
    reply
}) => {
    try {
        // Constructing the menu message
        let madeMenu = `
   *KRUTOV-MD WHATSAPP USER BOT* 💫

MY MISSION

This bot is the result of relentless effort and innovation. I, KRUTOV-MD, fully own all rights to the bot and its source code. No one is permitted to copy, modify, rebrand, or distribute this bot under any circumstances. With 100+ commands and advanced AI features, this bot stands out—and it's here to stay.

🐼 This bot aims to maximize WhatsApp's potential and ease user interaction.

💡 Download various resources and manage groups with ease. Features include logo creation, image editing options, searching for different content and more.

⚠️ I am not responsible for any bans on your WhatsApp account when using this bot. You use it at your own risk.

👨‍💻 OWNER: Jaden Afrix 

🎡 *GITHUB:* [https://github.com/Jaden-Afrix](https://github.com/Jaden-Afrix)
🎡 *REPOSITORY:* [https://github.com/Jaden-Afrix/KRUTOV-MD](https://github.com/Jaden-Afrix/KRUTOV-MD)

🪩 *JOIN MY GROUP:* [https://chat.whatsapp.com/H1nv6pTUhFj1tVYoPutW1g](https://chat.whatsapp.com/H1nv6pTUhFj1tVYoPutW1g)

*Please star the repo and follow me on GitHub!*
`;

        // Send the image and message
        await conn.sendMessage(from, {
            image: { url: 'https://ibb.co/JWcCCbLf' },
            caption: madeMenu,
            contextInfo: {
                mentionedJid: [m.sender],
                forwardingScore: 999,
                isForwarded: true,
                forwardedNewsletterMessageInfo: {
                    newsletterJid: '120363398430045533@newsletter',
                    newsletterName: '🪀『 KRUTOV-MD 』🪀',
                    serverMessageId: 143
                }
            }
        }, { quoted: mek });

        // Send intro audio
        await conn.sendMessage(from,{
            audio: { url: 'https://github.com/Jaden-Afrix/raw/refs/heads/main/autovoice/menu.mp3' },
            mimetype: 'audio/mp4',
            ptt: true
        }, { quoted: mek });

        // Confirm message success
        reply('The intro has been sent successfully!');

    } catch (e) {
        console.error('Error in processing intro command:', e);
        reply(`❌ An error occurred while processing your request: ${e.message || e}`);
    }
});