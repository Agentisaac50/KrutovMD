/*
Project Name : KRUTOV-MD 
Creator      : Jaden Afrix (Jaden Afrix )
Repo         : https://github.com/Jaden-Afrix/KRUTOV-MD 
Support      : wa.me/263784812740

### ⚠️ Disclaimer

- 🔒 This bot is **not affiliated with WhatsApp Inc.** Use it responsibly.
- 🚨 **Misuse may lead to account bans.**
- ❌ **Cloning or modifying the bot without permission is prohibited.**

---
*/

const config = require('../settings');
const { krutov, commands } = require('../krutov');


krutov({
    pattern: "about",
    alias: ["about"],
    react: "🧠",
    desc: "Get information about the bot and its creator.",
    category: "info",
    filename: __filename
}, async (conn, mek, m, { from, quoted, body, isCmd, command, args, q, isGroup, sender, senderNumber, botNumber2, botNumber, pushname, isMe, isOwner, groupMetadata, groupName, participants, groupAdmins, isBotAdmins, isAdmins, reply }) => {
    try {
        let madeMenu = `╭┄┅┅┅┅┅┅┅┅┅┅┅┅┅┅┅┅┅┅┅┅┅┅┅┅┅┅┅┅┅┅┅

*👋 Hello ${pushname}!*

I am *Malvin Xd*, a WhatsApp-based multi-device bot created by *Malvin King* from Zimbabwe.  
My sole purpose is to reduce the burden or cost of purchasing data bundles by allowing users to download songs, apps, videos, and movies using WhatsApp bundles.

For more information, please visit:

> *SOURCE CODE* : https://github.com/Jaden-Afrix 
> *FOLLOW OWNER* : https://github.com/Jaden-Afrix 
> *OWNER* : https://wa.me/263784812740/?text=KRUTOV-MD+Fan+Here  
> *SUPPORT CHANNEL* : https://whatsapp.com/channel/0029VbAhEUWGJP8QRH4IMw0s  
> *INSTAGRAM* : https://instagram.com/jaden.afrix 
> *YOUTUBE* : https://www.youtube.com/@jaden.afrix-z8f

*RELEASE DATE* — * 5 March 2025*

*— Jaden-Afrix*

━━━━━━━━━━━━━━━━━━━━━━━━
`;

        // Send image and info message
        await conn.sendMessage(
            from,
            {
                image: { url: 'https://files.catbox.moe/l1uebm.jpg' },
                caption: madeMenu,
                contextInfo: {
                    mentionedJid: [m.sender],
                    forwardingScore: 999,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: '120363398430045533@newsletter',
                        newsletterName: '🪀『KRUTOV-MD』🪀 ',
                        serverMessageId: 143
                    }
                }
            },
            { quoted: mek }
        );

        // Send audio message
        await conn.sendMessage(from, {
            audio: { url: 'https://github.com/raw/refs/heads/main/autovoice/alive.mp3' },
            mimetype: 'audio/mp3',
            ptt: true
        }, { quoted: mek });

    } catch (e) {
        console.log(e);
        reply(`${e}`);
    }
});