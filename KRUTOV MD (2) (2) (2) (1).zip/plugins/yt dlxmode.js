const axios = require("axios");
const { krutov } = require("../krutov");
const yts = require("yt-search");

// Song Downloader Command
krutov(
  {
    pattern: "songx",
    alias: ["mp3x", "ytmp3"],
    desc: "Download a song from YouTube as MP3.",
    category: "download",
    use: "<song name or YouTube URL>\nExample: .song faded\nExample: .song https://youtu.be/UDSYAD1sQuE",
    filename: __filename,
    react: "🎵",
  },
  async (conn, mek, m, { args, reply, from }) => {
    try {
      const input = args.join(" ");
      
      if (!input) {
        return reply(
          "⚠️ Please provide a song name or YouTube URL.\nExample: `.song faded`\nExample: `.song https://youtu.be/UDSYAD1sQuE`"
        );
      }
      
      let youtubeUrl;
      
      // Check if input is a YouTube URL
      if (input.startsWith("http://") || input.startsWith("https://")) {
        youtubeUrl = input;
      } else {
        const searchResults = await yts(input);
        if (!searchResults || searchResults.videos.length === 0) {
          return reply("❌ No results found for your query. Please try again.");
        }
        youtubeUrl = searchResults.videos[0].url;
      }
      
      // Fetch song download link from API
      const apiUrl = `https://bk9.fun/download/ytmp3?url=${encodeURIComponent(
        youtubeUrl
      )}&type=mp3`;
      const response = await axios.get(apiUrl);
      
      console.log("API Response:", response.data);
      
      if (!response.data?.status || !response.data?.BK9?.downloadUrl) {
        return reply("❌ Unable to fetch the song. Please check the URL and try again.");
      }
      
      const { title, downloadUrl } = response.data.BK9;
      
      await conn.sendMessage(from, {
        audio: { url: downloadUrl },
        mimetype: "audio/mpeg",
        fileName: `${title}.mp3`,
        caption: `🎵 *Title:* ${title}\n\n> © Gᴇɴᴇʀᴀᴛᴇᴅ ʙʏ KRUTOV-MD`,
      }, { quoted: mek });
      
    } catch (error) {
      console.error("Song Download Error:", error);
      reply("❌ An error occurred while downloading the song. Please try again later.");
    }
  }
);