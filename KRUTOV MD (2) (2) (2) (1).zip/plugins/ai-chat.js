// Existing code...

// Meta AI
krutov({
    pattern: "metaai",
    alias: ["metabot", "metagpt"],
    desc: "Chat with Meta AI",
    category: "ai",
    react: "📚",
    filename: __filename
},
async (conn, mek, m, { from, args, q, reply, react }) => {
    try {
        if (!q) return reply("Please provide a message for Meta AI.\nExample: `.metaai Hello`");

        const apiUrl = `https://meta-ai-api-url.com/api/chat?q=${encodeURIComponent(q)}`; // Replace with actual API
        const { data } = await axios.get(apiUrl);

        if (!data || !data.response) {
            await react("❌");
            return reply("Meta AI failed to respond. Please try again later.");
        }

        await reply(`📚 *Meta AI Response:*\n\n${data.response}`);
        await react("✅");
    } catch (e) {
        console.error("Error in Meta AI command:", e);
        await react("❌");
        reply("An error occurred while communicating with Meta AI.");
    }
});

// Claude AI
krutov({
    pattern: "claude",
    alias: ["claudeai"],
    desc: "Chat with Claude AI",
    category: "ai",
    react: "📩",
    filename: __filename
},
async (conn, mek, m, { from, args, q, reply, react }) => {
    try {
        if (!q) return reply("Please provide a message for Claude AI.\nExample: `.claude Hello`");

        const apiUrl = `https://claude-ai-api-url.com/v1/chat?q=${encodeURIComponent(q)}`; // Replace with actual API
        const { data } = await axios.get(apiUrl);

        if (!data || !data.reply) {
            await react("❌");
            return reply("Claude AI failed to respond. Please try again later.");
        }

        await reply(`📩 *Claude AI Response:*\n\n${data.reply}`);
        await react("✅");
    } catch (e) {
        console.error("Error in Claude AI command:", e);
        await react("❌");
        reply("An error occurred while communicating with Claude AI.");
    }
});

// Jasper AI
krutov({
    pattern: "jasper",
    alias: ["jasperai"],
    desc: "Chat with Jasper AI",
    category: "ai",
    react: "✍️",
    filename: __filename
},
async (conn, mek, m, { from, args, q, reply, react }) => {
    try {
        if (!q) return reply("Please provide a message for Jasper AI.\nExample: `.jasper Hello`");

        const apiUrl = `https://jasper-ai-api-url.com/api/ask?q=${encodeURIComponent(q)}`; // Replace with actual API
        const { data } = await axios.get(apiUrl);

        if (!data || !data.output) {
            await react("❌");
            return reply("Jasper AI failed to respond. Please try again later.");
        }

        await reply(`✍️ *Jasper AI Response:*\n\n${data.output}`);
        await react("✅");
    } catch (e) {
        console.error("Error in Jasper AI command:", e);
        await react("❌");
        reply("An error occurred while communicating with Jasper AI.");
    }
});

// Cohere AI
krutov({
    pattern: "cohere",
    alias: ["cohereai"],
    desc: "Chat with Cohere AI",
    category: "ai",
    react: "💡",
    filename: __filename
},
async (conn, mek, m, { from, args, q, reply, react }) => {
    try {
        if (!q) return reply("Please provide a message for Cohere AI.\nExample: `.cohere Hello`");

        const apiUrl = `https://cohere-ai-api-url.com/v1/query?q=${encodeURIComponent(q)}`; // Replace with actual API
        const { data } = await axios.get(apiUrl);

        if (!data || !data.answer) {
            await react("❌");
            return reply("Cohere AI failed to respond. Please try again later.");
        }

        await reply(`💡 *Cohere AI Response:*\n\n${data.answer}`);
        await react("✅");
    } catch (e) {
        console.error("Error in Cohere AI command:", e);
        await react("❌");
        reply("An error occurred while communicating with Cohere AI.");
    }
});

// EleutherAI
krutov({
    pattern: "eleutherai",
    alias: ["gptj"],
    desc: "Chat with EleutherAI's GPT-J model",
    category: "ai",
    react: "🧠",
    filename: __filename
},
async (conn, mek, m, { from, args, q, reply, react }) => {
   try {
       if (!q) return reply("Please provide a message for EleutherAI.\nExample: `.eleutherai Hello`");

       const apiUrl = `https://eleuther-ai-api-url.com/api/gptj?q=${encodeURIComponent(q)}`; // Replace with actual API
       const { data } = await axios.get(apiUrl);

       if (!data || !data.text) {
           await react("❌");
           return reply("EleutherAI failed to respond. Please try again later.");
       }

       await reply(`🧠 *EleutherAI Response:*\n\n${data.text}`);
       await react("✅");
   } catch (e) {
       console.error("Error in EleutherAI command:", e);
       await react("❌");
       reply("An error occurred while communicating with EleutherAI.");
   }
});