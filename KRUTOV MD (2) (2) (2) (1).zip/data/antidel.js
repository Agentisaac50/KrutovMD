const { DATABASE } = require('../lib/database');
const { DataTypes } = require('sequelize');

const AntiDelDB = DATABASE.define('AntiDelete', {
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true, // Changed to auto-increment
    },
    gc_status: {
        type: DataTypes.BOOLEAN,
        defaultValue: false,
    },
    dm_status: {
        type: DataTypes.BOOLEAN,
        defaultValue: false,
    },
}, {
    tableName: 'antidelete',
    timestamps: true, // Enable timestamps
});

let isInitialized = false;

async function initializeAntiDeleteSettings() {
    if (isInitialized) return;
    try {
        await AntiDelDB.sync();
        await AntiDelDB.findOrCreate({
            where: { id: 1 }, // Ensure at least one record exists
            defaults: { gc_status: false, dm_status: false },
        });
        isInitialized = true;
    } catch (error) {
        console.error('Error initializing anti-delete settings:', error);
    }
}

async function setAnti(type, status) {
    try {
        await initializeAntiDeleteSettings();
        const record = await AntiDelDB.findByPk(1);
        
        if (record) {
            if (type === 'gc') record.gc_status = status;
            else if (type === 'dm') record.dm_status = status;
            await record.save();
            return true;
        } else {
            console.error('No record found with ID = 1');
            return false;
        }
    } catch (error) {
        console.error('Error setting anti-delete status:', error);
        return false;
    }
}

async function toggleAnti(type) {
    try {
        await initializeAntiDeleteSettings();
        const record = await AntiDelDB.findByPk(1);

        if (record) {
            if (type === 'gc') record.gc_status = !record.gc_status;
            else if (type === 'dm') record.dm_status = !record.dm_status;
            await record.save();
            return true;
        } else {
            console.error('No record found with ID = 1');
            return false;
        }
    } catch (error) {
        console.error('Error toggling anti-delete status:', error);
        return false;
    }
}

async function getAnti(type) {
    try {
        await initializeAntiDeleteSettings();
        const record = await AntiDelDB.findByPk(1);
        
        if (record) {
            return type === 'gc' ? record.gc_status : record.dm_status;
        } else {
            console.error('No record found with ID = 1');
            return false;
        }
        
    } catch (error) {
        console.error('Error getting anti-delete status:', error);
        return false;
    }
}

async function getAllAntiDeleteSettings() {
    try {
        await initializeAntiDeleteSettings();
        const records = await AntiDelDB.findAll(); // Retrieve all records
        return records.map(record => ({
            id: record.id,
            gc_status: record.gc_status,
            dm_status: record.dm_status,
            createdAt: record.createdAt,
            updatedAt: record.updatedAt
        }));
    } catch (error) {
        console.error('Error retrieving all anti-delete settings:', error);
        return [];
    }
}

module.exports = {
    AntiDelDB,
    initializeAntiDeleteSettings,
    setAnti,
    toggleAnti, // Export new toggle function
    getAnti,
    getAllAntiDeleteSettings,
};

// by Jaden Afrix