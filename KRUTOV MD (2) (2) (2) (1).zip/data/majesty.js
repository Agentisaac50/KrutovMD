module.exports = {
  ADMIN_IMG: process.env.ADMIN_IMG || "https://ibb.co/JWcCCbLf", // 👤 Admin Menu
  PRIVATE_IMG: process.env.PRIVATE_IMG || "https://ibb.co/JWcCCbLf", // 📵 Private Menu
  MAIN_IMG: process.env.MAIN_IMG || "https://ibb.co/60h9gzMB", // 👻 Main Menu
  INFO_IMG: process.env.INFO_IMG || "https://ibb.co/JWcCCbLf", // 🔎 Info Menu
  SETTINGS_IMG: process.env.SETTINGS_IMG || "https://ibb.co/JWcCCbLf", // ⚙️ Settings Menu
  OWNER_IMG: process.env.OWNER_IMG || "https://ibb.co/JWcCCbLf", // 👑 Owner Menu
  DOWNLOAD_IMG: process.env.DOWNLOAD_IMG || "https://ibb.co/JWcCCbLf", // 📥 Download Menu
  MOVIE_IMG: process.env.MOVIE_IMG || "https://ibb.co/JWcCCbLf", // 📽 Movie Menu
  MAINMENU_IMG: process.env.MAINMENU_IMG || "https://ibb.co/JWcCCbLf", // 📋 Main Menu
  GROUP_IMG: process.env.GROUP_IMG || "https://ibb.co/JWcCCbLf", // 👨‍👩‍👦‍👦 Group Menu
  CONVERT_IMG: process.env.CONVERT_IMG || "https://ibb.co/JWcCCbLf", // 🔄 Convert Menu
  SEARCH_IMG: process.env.SEARCH_IMG || "https://ibb.co/JWcCCbLf", // 🔤 Search Menu
  UTILITY_IMG: process.env.UTILITY_IMG || "https://ibb.co/JWcCCbLf", // 🛑 Utility Menu
  FUN_IMG: process.env.FUN_IMG || "https://ibb.co/JWcCCbLf", // 😁 Fun Menu
  TOOLS_IMG: process.env.TOOLS_IMG || "https://ibb.co/JWcCCbLf", // 🔗 Tools Menu
  STICKER_IMG: process.env.STICKER_IMG || "https://ibb.co/JWcCCbLf", // 🙃 Sticker Menu
  RANDOM_IMG: process.env.RANDOM_IMG || "https://ibb.co/JWcCCbLf", // 🗣️ Random Menu
  MISC_IMG: process.env.MISC_IMG || "https://ibb.co/JWcCCbLf", // ⚙️ Misc Menu
  ANIME_IMG: process.env.ANIME_IMG || "https://ibb.co/JWcCCbLf", // 🎌 Anime Menu
  SUPPORT_IMG: process.env.SUPPORT_IMG || "https://ibb.co/JWcCCbLf", // 💬 Support Menu
  AI_IMG: process.env.AI_IMG || "https://ibb.co/JWcCCbLf", // 🤖 AI Menu
  OTHER_IMG: process.env.OTHER_IMG || "", // 🕳 Other Menu
  NSFW_IMG: process.env.NSFW_IMAGE || "https://ibb.co/bg6rX0P2" // 🔞 NSFW Menu
};