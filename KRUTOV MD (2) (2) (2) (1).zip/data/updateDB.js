const { DATABASE } = require('../lib/database');
const { DataTypes } = require('sequelize');

const UpdateDB = DATABASE.define('UpdateInfo', {
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true, // Auto-increment the primary key
    },
    commitHash: {
        type: DataTypes.STRING,
        allowNull: false,
    },
}, {
    tableName: 'update_info',
    timestamps: false,
});

// Initialize the database and make sure the entry exists
async function initializeUpdateDB() {
    await UpdateDB.sync(); // Ensure the table is created

    // Find or create the initial record if it doesn't exist
    const [record] = await UpdateDB.findOrCreate({
        where: { id: 1 },
        defaults: { commitHash: 'unknown' },
    });
    
    return record;
}

// Set a new commit hash
async function setCommitHash(hash) {
    const record = await initializeUpdateDB();
    
    if (record) {
        record.commitHash = hash; // Update the commit hash
        await record.save(); // Save the changes
    }
}

// Get the current commit hash, returning a default if not found
async function getCommitHash() {
    const record = await initializeUpdateDB();
    return record ? record.commitHash : 'unknown'; // Fallback to 'unknown'
}

// Optional: A method to reset the commit hash to 'unknown'
async function resetCommitHash() {
    const record = await initializeUpdateDB();
    
    if (record) {
        record.commitHash = 'unknown';
        await record.save();
    }
}

module.exports = {
    UpdateDB,
    setCommitHash,
    getCommitHash,
    resetCommitHash, // Exporting the new reset function
};

// by Jaden-Afrix