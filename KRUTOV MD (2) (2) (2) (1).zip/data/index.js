// Import dependencies related to anti-deletion settings and message handling
const {
    AntiDelDB,
    initializeAntiDeleteSettings,
    setAnti,
    getAnti,
    getAllAntiDeleteSettings,
} = require('./antidel');

const {
    saveContact,
    loadMessage,
    getName,
    getChatSummary,
    saveGroupMetadata,
    getGroupMetadata,
    saveMessageCount,
    getInactiveGroupMembers,
    getGroupMembersMessageCount,
    saveMessage,
} = require('./store');

/**
 * Initializes the anti-delete system by loading existing settings.
 * This should be called at the start of your application.
 */
function initializeSystem() {
    try {
        initializeAntiDeleteSettings();
        console.log('Anti-delete settings initialized successfully.');
    } catch (error) {
        console.error('Error initializing anti-delete settings:', error);
    }
}

/**
 * Updates the anti-delete permissions for a specific chat or group.
 * @param {string} chatId - The identifier for the chat group or individual.
 * @param {boolean} status - The new status to set (true for enabled, false for disabled).
 */
async function updateAntiDeleteStatus(chatId, status) {
    try {
        await setAnti(chatId, status);
        console.log(`Updated anti-delete status for ${chatId} to ${status}`);
    } catch (error) {
        console.error(`Failed to update anti-delete status for ${chatId}:`, error);
    }
}

/**
 * Retrieves anti-delete settings for a specific chat or group.
 * @param {string} chatId - The identifier for the chat to be queried.
 * @returns {Object|null} - Returns the anti-delete settings or null if not found.
 */
async function retrieveAntiDeleteSettings(chatId) {
    try {
        const settings = await getAnti(chatId);
        console.log(`Retrieved anti-delete settings for ${chatId}:`, settings);
        return settings;
    } catch (error) {
        console.error(`Error retrieving anti-delete settings for ${chatId}:`, error);
        return null;
    }
}

/**
 * Retrieves all available anti-delete settings in the system.
 * @returns {Array} - An array of all anti-delete settings.
 */
async function retrieveAllAntiDeleteSettings() {
    try {
        const allSettings = await getAllAntiDeleteSettings();
        console.log('Retrieved all anti-delete settings:', allSettings);
        return allSettings;
    } catch (error) {
        console.error('Error retrieving all anti-delete settings:', error);
        return [];
    }
}

/**
 * Saves a new contact to the database.
 * @param {Object} contact - The contact information to save.
 */
async function createContact(contact) {
    try {
        await saveContact(contact);
        console.log('Contact saved successfully:', contact);
    } catch (error) {
        console.error('Error saving contact:', error);
    }
}

/**
 * Loads a message given its ID.
 * @param {string} messageId - The identifier of the message to load.
 */
async function fetchMessageById(messageId) {
    try {
        const message = await loadMessage(messageId);
        console.log(`Loaded message:`, message);
        return message;
    } catch (error) {
        console.error(`Error loading message with ID ${messageId}:`, error);
        return null;
    }
}

/**
 * Retrieves members who haven't interacted in a designated timeframe from a group.
 * @param {string} groupId - The identifier of the group being queried.
 */
async function fetchInactiveMembers(groupId) {
    try {
        const inactiveMembers = await getInactiveGroupMembers(groupId);
        console.log(`Inactive members in ${groupId}:`, inactiveMembers);
        return inactiveMembers;
    } catch (error) {
        console.error(`Error fetching inactive members from ${groupId}:`, error);
        return [];
    }
}

// Exporting all modules including new functionalities
module.exports = {
    AntiDelDB,
    
    // Anti Delete Functions
    initializeAntiDeleteSettings,
    setAnti,
    getAnti,
    getAllAntiDeleteSettings,

     // Message and Contact Functions
     saveContact,
     loadMessage,
     getName,
     getChatSummary,
     saveGroupMetadata,
     getGroupMetadata,
     saveMessageCount,

     // Enhanced Functions
     createContact,
     fetchMessageById,
     retrieveAllAntiDeleteSettings,
     updateAntiDeleteStatus,
     retrieveAntiDeleteSettings,
     fetchInactiveMembers,

     // Group Functions
     getInactiveGroupMembers,
     getGroupMembersMessageCount,     
};

// Initialization on module loading if applicable
initializeSystem();